<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

	public function __construct()
 	{
 		parent::__construct();
 		$this->load->model('M_web');
  	}

  	#public $data = array(
  		#"nim" => "Nim Kalian",
  		#"nama" => "Isi Nama Kalian",
  		#"kampus"=>"Telkom University"
  	#);

	public function index()
	{
		$this->load->view('header');
		$this->load->view('news');
	}

	public function mahasiswa()
	{
		$data_mahasiswa = $this->M_web->Getmahasiswa_username();
        $this->load->view('header');
		$this->load->view('page_mahasiswa',['data'=>$data_mahasiswa]);
        
	}

	#lengkapi FUNCTION BERIKUT
	public function hapusmahasiswa($username)
	{
		$this->M_web->hapus_mahasiswa($username);
		redirect('index.php/web/mahasiswa');	
	}


	public function tambahmahasiswa()
	{
		$username = $this->input->post('username');
		$nama = $this->input->post('nama');
		$kategori = $this->input->post('kategori');
		$topic = $this->input->post('topic');
        $description = $this->input->post('description');
		$data = array(
			'username' => $username,
			'nama' => $nama,
			'kategori' => $kategori,
			'topic' => $topic,
            'description' => $description,
		);
		$this->M_web->tambah_mahasiswa($data);

		redirect('index.php/web/mahasiswa');	

	}

	public function editmahasiswa()
	{
		
        $username = $this->input->post('username');
		$nama = $this->input->post('nama');
		$kategori = $this->input->post('kategori');
		$topic = $this->input->post('topic');
        $description = $this->input->post('description');
		$data = array(
			'nama' => $nama,
			'kategori' => $kategori,
			'topic' => $topic,
            'description' => $description,
		);
		$this->M_web->edit_mahasiswa($username,$data);

		redirect('index.php/web/mahasiswa');	
	}


}
