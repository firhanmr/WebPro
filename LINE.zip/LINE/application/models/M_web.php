<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_web extends CI_Model {

	public function GetMahasiswa_username(){
		$this->db->select('*');
		$this->db->from('mahasiswa');
		$query = $this->db->get();
		return $query->result();
	}

	public function hapus_mahasiswa($username)
	{
		$this->db->delete('mahasiswa', array('username' => $username));
	    return;
	}

	public function edit_mahasiswa($username,$data)
	{
		$this->db->where('username', $username);
		$this->db->update('mahasiswa', $data);
	    return;
	}
	public function tambah_mahasiswa($data)
	{
		$this->db->insert('mahasiswa',$data);
	    return;
	}
}
