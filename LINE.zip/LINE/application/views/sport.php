<div id="container" class=" ">
      <div class="inner">
            <div class="left-area" id="left_area">
                  <h2 class="sub-title">Sports</h2>

                  <div class="begin">
                        <div class="section-hl ">

                              <a href="<?php base_url(); ?>detail_sport" class="lnk _link_home " title="Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China" data-title="article" data-order="0" data-articleid="68223047" data-pbt="1555165566000" data-module="322" data-categoryname="Sports">
                                    <figure class="fig-img" style="background-image:url(<?php echo base_url(); ?>assets/img/sport/w1200.jpeg)">

                                    </figure>
                                    <div class="txt">
                                          <span class="media _media">CNN Indonesia</span>

                                          <p class="content">Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China</p>
                                    </div>

                                    <span class="cover"></span>
                              </a>
                        </div>



                        <ul class="list-type-1">
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Bintang+Lapangan+Ini+10+Potret+Energik+Sitha+Marino+Saat+Main+Basket-pnLlYa" class="lnk _link_home " title="Bintang Lapangan, Ini 10 Potret Energik Sitha Marino Saat Main Basket" data-title="article" data-order="0" data-articleid="68220737" data-pbt="1555161900000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img" style="background-image:url(<?php echo base_url(); ?>assets/img/sport/w580.jpeg)">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Bintang Lapangan, Ini 10 Potret Energik Sitha Marino Saat Main Basket</p>
                                                <span class="media _media">IDN Times</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Marquez+Rossi+Angkat+Bicara+soal+Jabat+Tangan+di+Argentina-vnl8Y8" class="lnk _link_home " title="Marquez-Rossi Angkat Bicara soal Jabat Tangan di Argentina" data-title="article" data-order="1" data-articleid="68209404" data-pbt="1555150500000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img" style="background-image:url(<?php echo base_url(); ?>assets/img/sport/w580-2.jpeg)">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Marquez-Rossi Angkat Bicara soal Jabat Tangan di Argentina</p>
                                                <span class="media _media">Okezone.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Jamu+Chelsea+Liverpool+Dihantui+Kisah+Buruk+Lima+Musim+Lalu-Dyp7om" class="lnk _link_home " title="Jamu Chelsea, Liverpool Dihantui Kisah Buruk Lima Musim Lalu" data-title="article" data-order="2" data-articleid="68205840" data-pbt="1555145940000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img" style="background-image:url(<?php echo base_url(); ?>assets/img/sport/w580-3.jpeg)">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Jamu Chelsea, Liverpool Dihantui Kisah Buruk Lima Musim Lalu</p>
                                                <span class="media _media">Medcom.id</span>

                                          </div>

                                    </a>
                              </li>


                        </ul>
                  </div>

                  <div class="operation-module ">
                        <div class="bx-title">

                              <h3 class="section-title">FOOTBALL</h3>
                        </div>
                        <ul class="list-type-1">
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Van+Dijk+Sarankan+Rekannya+Diam+di+Rumah+Jika+Tak+Yakin+Liverpool+Rebut+2+Gelar-MEr7Ma" class="lnk _link_home " title="Van Dijk Sarankan Rekannya Diam di Rumah Jika Tak Yakin Liverpool Rebut 2 Gelar" data-title="operation1_article" data-order="0" data-articleid="68039307" data-pbt="1554957240000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img fig-lazy" data-background="<?php echo base_url(); ?>assets/img/sport/w580-19.jpeg">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Van Dijk Sarankan Rekannya Diam di Rumah Jika Tak Yakin Liverpool Rebut 2 Gelar</p>
                                                <span class="media _media">Bola.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Valverde+Akui+Tak+Mudah+Barcelona+Menang+di+Markas+MU-onZK6j" class="lnk _link_home " title="Valverde Akui Tak Mudah Barcelona Menang di Markas MU" data-title="operation1_article" data-order="1" data-articleid="68037093" data-pbt="1554955560000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img fig-lazy" data-background="<?php echo base_url(); ?>assets/img/sport/w580-20.jpeg">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Valverde Akui Tak Mudah Barcelona Menang di Markas MU</p>
                                                <span class="media _media">Liputan6.com</span>

                                          </div>

                                    </a>
                              </li>

                        </ul>
                  </div>

                  <div class="operation-module ">
                        <div class="bx-title">

                              <h3 class="section-title">MOTO GP</h3>
                        </div>
                        <ul class="list-type-1">
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Tegangnya+Rossi+Mengaspal+di+Austin-ORO7RG" class="lnk _link_home " title="Tegangnya Rossi Mengaspal di Austin" data-title="operation2_article" data-order="0" data-articleid="68037660" data-pbt="1554956100000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img fig-lazy" data-background="<?php echo base_url(); ?>assets/img/sport/w580-25.jpeg">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Tegangnya Rossi Mengaspal di Austin</p>
                                                <span class="media _media">VIVA.CO.ID</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Dovizioso+Targetkan+Podium+di+COTA-z9VQoJ" class="lnk _link_home " title="Dovizioso Targetkan Podium di COTA" data-title="operation2_article" data-order="1" data-articleid="68032143" data-pbt="1554951660000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img fig-lazy" data-background="<?php echo base_url(); ?>assets/img/sport/w580-26.jpeg">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Dovizioso Targetkan Podium di COTA</p>
                                                <span class="media _media">SINDOnews</span>

                                          </div>

                                    </a>
                              </li>

                        </ul>
                  </div>
            </div>

            <aside class="right-area" id="right_area">



                  <div class="aside-section popular _side_popular">
                        <h3 class="section-title">Populer</h3>
                        <div id="nav" class="nav">
                              <div class="scroll_wrap swiper-container">
                                    <ul class="nav_u _scroller">



                                          <li class="_slide _link" data-tabid="100270" data-tabindex="0" data-tabname="Semua"><a href="#" class="nav_a" title="Semua">Semua</a></li>


                                          <li class="_slide _link" data-tabid="100271" data-tabindex="1" data-tabname="News"><a href="#" class="nav_a" title="News">News</a></li>



                                          <li class="_slide _link nav_lon" data-tabid="100293" data-tabindex="2" data-tabname="Sports"><a href="#" class="nav_a" title="Sports">Sports</a></li>
                                    </ul>
                              </div>
                              <div class="bx-btn">
                                    <button type="button" class="sp btn-prev _slide_popular_prev _link"><span class="blind">Prev</span></button>
                                    <button type="button" class="sp btn-next _slide_popular_next _link"><span class="blind">Next</span></button>
                              </div>
                              <span class="cover"></span>
                        </div>
                        <ol class="list-type-rk _side_popular_100270" style="display:none">
                              <li>

                                    <a href="#" class="subtit _link _popular " title="Foto: Lautan Massa Jokowi Putihkan GBK" data-articleid="68209341" data-order="0" data-pbt="1555149840000">
                                          Foto: Lautan Massa Jokowi Putihkan GBK
                                    </a>
                                    <span class="media _media">kumparan</span>

                              </li>
                              <li>

                                    <a href="#" class="subtit _link _popular " title="Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China" data-articleid="68223047" data-order="1" data-pbt="1555165566000">
                                          Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China
                                    </a>
                                    <span class="media _media">CNN Indonesia</span>

                              </li>
                              
                        </ol>
                        
                        
                        <ol class="list-type-rk _side_popular_100271" style="display:none">
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Foto+Lautan+Massa+Jokowi+Putihkan+GBK-aewRqn" class="subtit _link _popular " title="Foto: Lautan Massa Jokowi Putihkan GBK" data-articleid="68209341" data-order="0" data-pbt="1555149840000">
                                          Foto: Lautan Massa Jokowi Putihkan GBK
                                    </a>
                                    <span class="media _media">kumparan</span>

                              </li>
                              
                        </ol>
                        <ol class="list-type-rk _side_popular_100293" style="display:block">
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Ahsan+Hendra+Tak+Sangka+Menang+Telak+Atas+Ganda+China-LDOa0V" class="subtit _link _popular " title="Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China" data-articleid="68223047" data-order="0" data-pbt="1555165566000">
                                          Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China
                                    </a>
                                    <span class="media _media">CNN Indonesia</span>

                              </li>
                              
                        </ol>
                        
                        
            
                        <a href="#" class="btn-more _side_popular_more _link" data-currentid="100293" data-index=2 data-categoryname="Sports" title="Lainnya">Lainnya</a>
                  </div>

                        <div class="bx-btn">
                              <button type="button" class="sp btn-prev _side_hot_prev _link"><span class="blind">Prev</span></button>
                              <button type="button" class="sp btn-next _side_hot_next _link"><span class="blind">Next</span></button>
                        </div>
                  </div>

            </aside>
      </div>
</div>
