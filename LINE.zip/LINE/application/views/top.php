<div id="container" class="top ">
      <div class="inner">

            <div class="digest-module">
                  <div class="left-swipe">
                        <div class="img-swiper-container section-hl top">
                              <ul class="swiper-wrapper slide">
                                    <li class="swiper-slide">

                                          <a href="?php base_url(); ?>detail_top" class="lnk _link_home " title="Gempa Banggai Sulteng Diakibatkan Pergerakan Sesar Lokal" data-title="digest_thumbnailarticle" data-order="0" data-articleid="68163582" data-pbt="1555084620000" data-module="321" data-categoryname="News">
                                                <figure class="fig-img swiper-lazy" data-background="<?php echo base_url(); ?>assets/img/w1200-2.jpeg">

                                                </figure>

                                                <span class="cover"></span>
                                          </a>
                                    </li>
                                    <li class="swiper-slide">

                                          <a href="#" class="lnk _link_home " title="Deretan Tokoh 'Calon Menteri' Prabowo" data-title="digest_thumbnailarticle" data-order="1" data-articleid="68152454" data-pbt="1555085100000" data-module="321" data-categoryname="News">
                                                <figure class="fig-img swiper-lazy" data-background="<?php echo base_url(); ?>assets/img/w1200-3.jpeg">

                                                </figure>

                                                <span class="cover"></span>
                                          </a>
                                    </li>
                                    <li class="swiper-slide">

                                          <a href="#" class="lnk _link_home " title="BMKG Catat 20 Kali Gempa Susulan di Sulteng" data-title="digest_thumbnailarticle" data-order="2" data-articleid="68163316" data-pbt="1555081697000" data-module="321" data-categoryname="News">
                                                <figure class="fig-img swiper-lazy" data-background="<?php echo base_url(); ?>assets/img/w1200-4.jpeg">

                                                </figure>

                                                <span class="cover"></span>
                                          </a>
                                    </li>
                                    <li class="swiper-slide">

                                          <a href="#" class="lnk _link_home " title="7 Sudut Seram Rumah Anang Hermasyah, Sering Lihat Penampakan" data-title="digest_thumbnailarticle" data-order="3" data-articleid="68135500" data-pbt="1555061700000" data-module="321" data-categoryname="Life">
                                                <figure class="fig-img swiper-lazy" data-background="<?php echo base_url(); ?>assets/img/w1200-5.jpeg">

                                                </figure>

                                                <span class="cover"></span>
                                          </a>
                                    </li>
                                    <li class="swiper-slide">

                                          <a href="#" class="lnk _link_home " title="KPU dan Bawaslu Gagal Lihat Bukti Surat Suara Tercoblos di Malaysia" data-title="digest_thumbnailarticle" data-order="4" data-articleid="68165425" data-pbt="1555085160000" data-module="321" data-categoryname="News">
                                                <figure class="fig-img swiper-lazy" data-background="<?php echo base_url(); ?>assets/img/w1200-6.jpeg">

                                                </figure>

                                                <span class="cover"></span>
                                          </a>
                                    </li>
                                    <li class="swiper-slide">

                                          <a href="#" class="lnk _link_home " title="Pangeran William Jawab Isu Perselingkuhan dengan Bangsawan Cantik Ini" data-title="digest_thumbnailarticle" data-order="5" data-articleid="68163418" data-pbt="1555084800000" data-module="321" data-categoryname="Showbiz">
                                                <figure class="fig-img swiper-lazy" data-background="<?php echo base_url(); ?>assets/img/w1200-7.jpeg">

                                                </figure>

                                                <span class="cover"></span>
                                          </a>
                                    </li>
                                    <li class="swiper-slide">

                                          <a href="#" class="lnk _link_home " title="Kisah Tiga Ojek Online yang Antarkan Makanan ke Rumah Luna Maya Berbarengan" data-title="digest_thumbnailarticle" data-order="6" data-articleid="68163056" data-pbt="1555085400000" data-module="321" data-categoryname="Showbiz">
                                                <figure class="fig-img swiper-lazy" data-background="<?php echo base_url(); ?>assets/img/w1200-8.jpeg">

                                                </figure>

                                                <span class="cover"></span>
                                          </a>
                                    </li>
                                    <li class="swiper-slide">

                                          <a href="#" class="lnk _link_home " title="Viral Cewek Cancel Orderan Ojek Online Karena Anggap Driver Jelek" data-title="digest_thumbnailarticle" data-order="7" data-articleid="68150988" data-pbt="1555086420000" data-module="321" data-categoryname="Fun">
                                                <figure class="fig-img swiper-lazy" data-background="<?php echo base_url(); ?>assets/img/w1200.jpeg">

                                                </figure>

                                                <span class="cover"></span>
                                          </a>
                                    </li>
                              </ul>
                              <div class="bx-slide-dot swiper-pagination"></div>
                        </div>
                        <section class="section-hl-article">

                              <a href="#" class="lnk _link_home " title="Gempa Banggai Sulteng Diakibatkan Pergerakan Sesar Lokal" data-title="digest_thumbnailarticle" data-order="0" data-articleid="68163582" data-pbt="1555084620000" data-module="321" data-categoryname="News">
                                    <h2 class="news-title _digest_news_title">Gempa Banggai Sulteng Diakibatkan Pergerakan Sesar Lokal</h2>
                                    <p class="content">JAKARTA - Kepala Badan Meteorologi, Klimatologi, dan Geofisika (BMKG) Dwikorita Karnawati menjelaskan setelah melakukan pemutakhiran kekuatan gempa di Banggai Kepulauan, Sulawesi Tengah berkekuatan magnitudo 6,8. Sebelumnya dikabarkan magnitudo 6,9. �Dilakukan pemutakhiran kekuatan gempa menjadi mag</p>
                                    <div class="bx-category">
                                          <span class="category">News</span>
                                          <span class="media _media">Okezone.com</span>

                                    </div>
                              </a>

                              <a href="#" class="lnk _link_home " title="Deretan Tokoh 'Calon Menteri' Prabowo" data-title="digest_thumbnailarticle" data-order="1" data-articleid="68152454" data-pbt="1555085100000" data-module="321" data-categoryname="News">
                                    <h2 class="news-title _digest_news_title">Deretan Tokoh 'Calon Menteri' Prabowo</h2>
                                    <p class="content">VIVA � Sejumlah tokoh nasional, ulama dan elit partai politik menghadiri acara pidato kebangsaan calon presiden nomor urut 02 Prabowo-Subianto di Dyandra Convention Hall Surabaya, Jawa Timur, pada Jumat, 12 April 2019. Sebelum berpidato, Prabowo mengeenalkan satu persatu nama-nama tokoh yang hadi</p>
                                    <div class="bx-category">
                                          <span class="category">News</span>
                                          <span class="media _media">VIVA.CO.ID</span>

                                    </div>
                              </a>

                              <a href="#" class="lnk _link_home " title="BMKG Catat 20 Kali Gempa Susulan di Sulteng" data-title="digest_thumbnailarticle" data-order="2" data-articleid="68163316" data-pbt="1555081697000" data-module="321" data-categoryname="News">
                                    <h2 class="news-title _digest_news_title">BMKG Catat 20 Kali Gempa Susulan di Sulteng</h2>
                                    <p class="content">Badan Meteorologi, Klimatologi, dan Geofisika (BMKG) mencatat telah terjadi gempa susulan sebanyak 20 kali usai gempa yang terjadi pada pukul 18.40 WIB di Teluk Tolo atau 82 km barat daya Kepulauan Banggai, Sulawesi Tengah. "Hingga pukul 21.00 WIB, hasil monitoring BMKG menunjukkan aktivitas gempa b</p>
                                    <div class="bx-category">
                                          <span class="category">News</span>
                                          <span class="media _media">CNN Indonesia</span>

                                    </div>
                              </a>

                              <a href="#" class="lnk _link_home " title="7 Sudut Seram Rumah Anang Hermasyah, Sering Lihat Penampakan" data-title="digest_thumbnailarticle" data-order="3" data-articleid="68135500" data-pbt="1555061700000" data-module="321" data-categoryname="Life">
                                    <h2 class="news-title _digest_news_title">7 Sudut Seram Rumah Anang Hermasyah, Sering Lihat Penampakan</h2>
                                    <p class="content">Aurel Hermansyah dan sang adik Azriel mengungkap jika rumah yang ditinggalinya ini bersama orangtua miliki cerita seram. Bahkan Azriel sendiri pernah mendapat gangguan dari makhluk halus tersebut. Cerita lain juga datang dari para karyawan mereka. Seperti inilah potret sudut rumah mereka, yang katan</p>
                                    <div class="bx-category">
                                          <span class="category">Life</span>
                                          <span class="media _media">KapanLagi.com</span>

                                    </div>
                              </a>

                              <a href="#" class="lnk _link_home " title="KPU dan Bawaslu Gagal Lihat Bukti Surat Suara Tercoblos di Malaysia" data-title="digest_thumbnailarticle" data-order="4" data-articleid="68165425" data-pbt="1555085160000" data-module="321" data-categoryname="News">
                                    <h2 class="news-title _digest_news_title">KPU dan Bawaslu Gagal Lihat Bukti Surat Suara Tercoblos di Malaysia</h2>
                                    <p class="content">Anggota Komisi Pemilihan Umum (KPU) RI, Hasyim Asy'ari dan Ilham Saputra serta anggota Badan Pengawas Pemilu (Bawaslu) RI Ratna Dewi Pettalolo gagal melihat barang bukti surat suara tercoblos di Jalan Seksyen 2/11 Kajang, Selangor. Rombongan yang berangkat bersama-sama dari KBRI Kuala Lumpur tersebu</p>
                                    <div class="bx-category">
                                          <span class="category">News</span>
                                          <span class="media _media">Merdeka.com</span>

                                    </div>
                              </a>

                              <a href="<?php echo base_url(); ?>assets/img/w1200-2.jpeg" class="lnk _link_home " title="Pangeran William Jawab Isu Perselingkuhan dengan Bangsawan Cantik Ini" data-title="digest_thumbnailarticle" data-order="5" data-articleid="68163418" data-pbt="1555084800000" data-module="321" data-categoryname="Showbiz">
                                    <h2 class="news-title _digest_news_title">Pangeran William Jawab Isu Perselingkuhan dengan Bangsawan Cantik Ini</h2>
                                    <p class="content">LONDON - Akhir Maret silam, Pangeran William santer diberitakan terlibat perselingkuhan dengan Rose Hanbury. Perselingkuhan tersebut dikabarkan membuat Kate Middleton murka karena Hanbury adalah salah satu sahabatnya. Isu perselingkuhan itu, kemudian dibantah Pangeran William lewat firma hukum Harbo</p>
                                    <div class="bx-category">
                                          <span class="category">Showbiz</span>
                                          <span class="media _media">Okezone.com</span>

                                    </div>
                              </a>

                              <a href="#" class="lnk _link_home " title="Kisah Tiga Ojek Online yang Antarkan Makanan ke Rumah Luna Maya Berbarengan" data-title="digest_thumbnailarticle" data-order="6" data-articleid="68163056" data-pbt="1555085400000" data-module="321" data-categoryname="Showbiz">
                                    <h2 class="news-title _digest_news_title">Kisah Tiga Ojek Online yang Antarkan Makanan ke Rumah Luna Maya Berbarengan</h2>
                                    <p class="content">Laporan Wartawan Grid.ID, Rissa Indrasty Grid.ID - Luna Maya tinggal di kediaman mewahnya di daerah Mampang, Jakarta Selatan. Meski rumah tersebut sangat luas, namun tempat tinggal Luna Maya yang terletak di pojok jalan tersebut tampak sepi. Tak hanya di sekitar jalan bahkan rumahnya yang ditutupi p</p>
                                    <div class="bx-category">
                                          <span class="category">Showbiz</span>
                                          <span class="media _media">grid.ID</span>

                                    </div>
                              </a>

                              <a href="#" class="lnk _link_home " title="Viral Cewek Cancel Orderan Ojek Online Karena Anggap Driver Jelek" data-title="digest_thumbnailarticle" data-order="7" data-articleid="68150988" data-pbt="1555086420000" data-module="321" data-categoryname="Fun">
                                    <h2 class="news-title _digest_news_title">Viral Cewek Cancel Orderan Ojek Online Karena Anggap Driver Jelek</h2>
                                    <p class="content">Brilio.net - Driver ojek online sepertinya saat ini menjadi profesi yang selalu menyimpan banyak cerita yang menarik. Bertemu tiap hari dengan banyak orang yang berbeda sifat dan kepribadian membuat para driver juga harus menyesuaikan. Ada yang perfeksionis meminta segala macam kelengkapan seperti m</p>
                                    <div class="bx-category">
                                          <span class="category">Fun</span>
                                          <span class="media _media">Brilio.net</span>

                                    </div>
                              </a>
                        </section>
                        <div class="bx-slide-arrow _digest_slide_arrow">
                              <button type="button" class="sp btn-prev swiper-act-prev" data-title="click_thumbnailarticle_left_button"><span class="blind">Prev</span></button>
                              <button type="button" class="sp btn-next swiper-act-next" data-title="click_thumbnailarticle_right_button"><span class="blind">Next</span></button>
                        </div>
                  </div>


                  <div class="section-hl-text">
                        <ul>
                              <li>

                                    <a href="#" class="lnk _link_home " title="[UPDATE] 1 Warga Meninggal Pasca-gempa di Banggai Kepulauan" data-title="breaking_article" data-order="0" data-articleid="68165084" data-pbt="1555085220000" data-module="321" data-categoryname="News">
                                          <div class="txt">

                                                <p class="content">[UPDATE] 1 Warga Meninggal Pasca-gempa di Banggai Kepulauan</p>
                                          </div>
                                    </a>
                              </li>
                        </ul>
                  </div>


            </div>
            <div class="left-area" id="left_area">

                  <div class="operation-module top">
                        <div class="bx-title">

                              <h3 class="section-title">TOP 10</h3>
                        </div>
                        <ul class="list-type-2">
                              <li>

                                    <a href="#" class="lnk _link_home " title="KPU Umumkan Harta Capres-Cawapres, Sandiaga Paling Kaya" data-title="operation7_article" data-order="0" data-articleid="68141984" data-pbt="1555062540000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hD_GvQKS4G3B6DzGnF3RkJ0BZGB9JYwhzHjlKbiphRUQFbF0hR2oGRVYIRkYCalwuFDpXFVkMAEFfaw4vQGkG/w580">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">KPU Umumkan Harta Capres-Cawapres, Sandiaga Paling Kaya</p>
                                                <span class="media _media">Merdeka.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="[HOAKS] Ketua Panwaslu Kuala Lumpur Berpose Dua Jari Dukung Prabowo-Sandiaga" data-title="operation7_article" data-order="1" data-articleid="68134960" data-pbt="1555060980000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hFwCfE4DiGVh-HzOPOHtmD0RJGjdNcwpbGilIRi5xR2wBfF8LEXtUNl0YFTwHKV4GF3hTO1oZAmlbewwIQXpU/w580">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">[HOAKS] Ketua Panwaslu Kuala Lumpur Berpose Dua Jari Dukung Prabowo-Sandiaga</p>
                                                <span class="media _media">Kompas.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Ular Berbisa Ditemukan di Paket Keripik Rendang" data-title="operation7_article" data-order="2" data-articleid="68134190" data-pbt="1555056229000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hvpYoxTadKV9kFgOIIZFWCF5AKjBXejpcACB4QTR4d2sbdW8MUSVnMUdGd2gaL24BDXFuOUYVMm5BcjwODyJn/w580">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Ular Berbisa Ditemukan di Paket Keripik Rendang</p>
                                                <span class="media _media">CNN Indonesia</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="8 Potret Selingkuhan Pangeran William, Temannya Kate Middleton!" data-title="operation7_article" data-order="3" data-articleid="68133271" data-pbt="1555057380000" data-module="322" data-categoryname="Showbiz">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hgLc3JU0dOGNeShK0FYRHNGQcOwxtJitgOnxpfQ4kZlchKX4wZSR_DX1JNVYhc389MH5_BXNMI1J7Li0yNyV_/w580">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">8 Potret Selingkuhan Pangeran William, Temannya Kate Middleton!</p>
                                                <span class="media _media">KapanLagi.com</span>

                                          </div>

                                    </a>
                              </li>
                        </ul>
                        <ul class="list-type-1">
                              <li>

                                    <a href="#" class="lnk _link_home " title="[ Eksklusif ] Perbedaan Film 'Sunyi' & 'Whispering Corridors' Hingga Cerita Mistis Pemain" data-title="operation7_article" data-order="0" data-articleid="68123067" data-pbt="1555066800000" data-module="322" data-categoryname="Channel">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hAV4CMR6bHnkJOjSuISlhLjNsHRY6Vg16bQxPZ1lUQE12WVgsMVlUSCpoSUp0WFknZwlVFy87BUgsXgsqZ15U/f198">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">[ Eksklusif ] Perbedaan Film 'Sunyi' & 'Whispering Corridors' Hingga Cerita Mistis Pemain</p>
                                                <span class="media _media">LINE TODAY</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Reaksi Janggal Pangeran William Soal Kabar Selingkuhi Sahabat Kate" data-title="operation7_article" data-order="1" data-articleid="68154539" data-pbt="1555052940000" data-module="322" data-categoryname="Showbiz">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0h3kNgQt04bERzHkaTXVITE0lIbytAcn9HFyg9WiNwMnAMfSoRTXhwKlAYNnYMeysaGngmKlQcd3VWenkXH3lw/f198">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Reaksi Janggal Pangeran William Soal Kabar Selingkuhi Sahabat Kate</p>
                                                <span class="media _media">VIVA.CO.ID</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Masinton Sempat Ditawari Mafia Jual Beli Surat Suara di Malaysia" data-title="operation7_article" data-order="2" data-articleid="68121033" data-pbt="1555045680000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hkwTg32fuNFhpHh6PeLZLD1NINzdacidbDShlRjlwamwWfXIOBy8saUoeaTtAfXMGBy9_OE4fL2lMeiELVyws/f198">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Masinton Sempat Ditawari Mafia Jual Beli Surat Suara di Malaysia</p>
                                                <span class="media _media">kumparan</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Muncul Sejumlah Kejanggalan Pada Kasus Audrey, Apakah Audrey Juga Bersalah?" data-title="operation7_article" data-order="3" data-articleid="68117048" data-pbt="1555043100000" data-module="322" data-categoryname="Life">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hjVX7fHm6NXllTh-uevZKLl8YNhZWIiZ6AXhkZzUga00aLXMvWnwtF0ZMPExIdnInDCl_GEhJLkhAKiAtUX0t/f198">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Muncul Sejumlah Kejanggalan Pada Kasus Audrey, Apakah Audrey Juga Bersalah?</p>
                                                <span class="media _media">hai-online.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Cerita Mistis Jembatan Angker, Lokasi Mayat dalam Koper" data-title="operation7_article" data-order="4" data-articleid="68154540" data-pbt="1555050720000" data-module="322" data-categoryname="Fun">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0h2SPcQYaFbXxtGkercsESK1dMbhNedn5_CSw8Yj10M0gSeSsqUnVwSUEcNERHeioiBHwhHkwSdk1IfngoWXpw/f198">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Cerita Mistis Jembatan Angker, Lokasi Mayat dalam Koper</p>
                                                <span class="media _media">Keepo.me</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Tak Takut Dibully, Gisella Anastasia Unggah Foto Bareng Wijin" data-title="operation7_article" data-order="5" data-articleid="68115905" data-pbt="1555043280000" data-module="322" data-categoryname="Showbiz">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hUJn0n5K2CmVTSSCyUOR1MmkfCQpgJRlmN39bewMnVFEsKkwyO3gVC3AdA1N_f007Oi9CBHRPEVR2LR8xa3sV/f198">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Tak Takut Dibully, Gisella Anastasia Unggah Foto Bareng Wijin</p>
                                                <span class="media _media">Suara.com</span>

                                          </div>

                                    </a>
                              </li>
                        </ul>
                  </div>
                  <div class="operation-module top">
                        <div class="bx-title">

                              <h3 class="section-title">SPORT</h3>
                        </div>
                        <ul class="list-type-2">
                              <li>

                                    <a href="#" class="lnk _link_home " title="Newcastle United tundukkan Leicester City" data-title="system6301" data-order="0" data-articleid="68181225" data-pbt="1555117597000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hHSLfWUCSF3xxHz2qS51oK0tJFBNCcwR_FSlGYiFxSUgOfFAoSyxcSV0aTB9dfVAiH3FQHF0fDE1UewUuGStc/w580">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Newcastle United tundukkan Leicester City</p>
                                                <span class="media _media">antaranews.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Espargaro terkesan dengan performa motor KTM di Austin" data-title="system6301" data-order="1" data-articleid="68178462" data-pbt="1555114387000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hUEOWQ3SsCmpyLiC8Vrh1PUh4CQVBQhlpFhhbdCJAVF4NTU0_RhpFX159UwlYTE00HB1FClEpEVtXShg4TxtF/w580">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Espargaro terkesan dengan performa motor KTM di Austin</p>
                                                <span class="media _media">antaranews.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Aspar Jaelolo juara ketiga Kejuaraan Dunia Panjat Tebing di Moscow" data-title="system6301" data-order="2" data-articleid="68180614" data-pbt="1555116877000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hy1iJQM8UJh5UMwzIbOZZSW5lJXFnXzUdMAV3AARdeCorUGFKbFxqcHc0cCwqBWFAOgFvenY3PS9xVzRMOlNq/w580">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Aspar Jaelolo juara ketiga Kejuaraan Dunia Panjat Tebing di Moscow</p>
                                                <span class="media _media">antaranews.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Pelatih LA Lakers akhirnya mundur" data-title="system6301" data-order="3" data-articleid="68174714" data-pbt="1555107204000" data-module="322" data-categoryname="Sports">
                                          <figure class="fig-img fig-lazy" data-background="https://obs.line-scdn.net/0hG9lvuexgGBZRDzLAU-FnQW5ZG3liYwsVNTlJCAFhRiIubF9BOjpeeHJdEiIoP19IPz5QNXUHEnN-OA9I/w580">

                                          </figure>
                                          <div class="txt">
                                                <p class="content">Pelatih LA Lakers akhirnya mundur</p>
                                                <span class="media _media">antaranews.com</span>

                                          </div>

                                    </a>
                              </li>
                        </ul>

                  </div>

            </div>

            <aside class="right-area" id="right_area">



                  <div class="aside-section popular _side_popular">
                        <h3 class="section-title">Populer</h3>
                        <div id="nav" class="nav">
                              <div class="scroll_wrap swiper-container">
                                    <ul class="nav_u _scroller">



                                          <li class="_slide _link nav_lon" data-tabid="100270" data-tabindex="0" data-tabname="Semua"><a href="#" class="nav_a" title="Semua">Semua</a></li>


                                          <li class="_slide _link" data-tabid="100271" data-tabindex="1" data-tabname="News"><a href="#" class="nav_a" title="News">News</a></li>



                                          <li class="_slide _link" data-tabid="100293" data-tabindex="2" data-tabname="Sports"><a href="#" class="nav_a" title="Sports">Sports</a></li>

                                    </ul>
                              </div>
                              <div class="bx-btn">
                                    <button type="button" class="sp btn-prev _slide_popular_prev _link"><span class="blind">Prev</span></button>
                                    <button type="button" class="sp btn-next _slide_popular_next _link"><span class="blind">Next</span></button>
                              </div>
                              <span class="cover"></span>
                        </div>
                        <ol class="list-type-rk _side_popular_100270" style="display:block">
                              <li>

                                    <a href="#" class="subtit _link _popular " title="Update Gempa Sulawesi Tengah, Peringatan Tsunami Dicabut & Keadaan Terkini Warga" data-articleid="68159283" data-order="0" data-pbt="1555077660000">
                                          Update Gempa Sulawesi Tengah, Peringatan Tsunami Dicabut & Keadaan Terkini Warga
                                    </a>
                                    <span class="media _media">LINE TODAY</span>
                              </li>
                              <li>

                                    <a href="#" class="subtit _link _popular " title="Ketua PSSI Jokdri Diancam Hukuman Penjara 13 Tahun 9 Bulan" data-articleid="68150936" data-order="0" data-pbt="1555069530000">
                                          Ketua PSSI Jokdri Diancam Hukuman Penjara 13 Tahun 9 Bulan
                                    </a>
                                    <span class="media _media">CNN Indonesia</span>

                              </li>
                        </ol>
                        <ol class="list-type-rk _side_popular_100271" style="display:none">
                              <li>

                                    <a href="#" class="subtit _link _popular " title="Update Gempa Sulawesi Tengah, Peringatan Tsunami Dicabut & Keadaan Terkini Warga" data-articleid="68159283" data-order="0" data-pbt="1555077660000">
                                          Update Gempa Sulawesi Tengah, Peringatan Tsunami Dicabut & Keadaan Terkini Warga
                                    </a>
                                    <span class="media _media">LINE TODAY</span>
                              </li>
                        </ol>
                        <ol class="list-type-rk _side_popular_100293" style="display:none">
                              <li>

                                    <a href="#" class="subtit _link _popular " title="Ketua PSSI Jokdri Diancam Hukuman Penjara 13 Tahun 9 Bulan" data-articleid="68150936" data-order="0" data-pbt="1555069530000">
                                          Ketua PSSI Jokdri Diancam Hukuman Penjara 13 Tahun 9 Bulan
                                    </a>
                                    <span class="media _media">CNN Indonesia</span>

                              </li>
                        </ol>
                        
                        <a href="#" class="btn-more _side_popular_more _link" data-currentid="100270" data-index=0 data-categoryname="Semua" title="Lainnya">Lainnya</a>
                  </div>

                  <div class="aside-section family-service">
                        <h3 class="section-title">Layanan LINE</h3>
                        <ul class="list-type-inlineBlock"></ul>
                  </div>





            </aside>
      </div>
</div>