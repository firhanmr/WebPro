<div id="container" class=" ">
      <div class="inner">
            <div class="left-area" id="left_area">
                  <h2 class="sub-title">News</h2>

                  <div class="begin">
                        <div class="section-hl ">

                              <a href="#" class="lnk _link_home " title="Fakta Pembunuhan Guru Honorer Terungkap! Pelaku Memotong Kepala Korban Secara Bergantian" data-title="digest_article" data-order="0" data-articleid="68248909" data-pbt="1555214760000" data-module="322" data-categoryname="News">
                                    <figure class="fig-img" style="background-image:url(<?php echo base_url(); ?>assets/img/news/w1200.jpeg)">

                                    </figure>
                                    <div class="text">
                                          <span class="media _media">Nakita.id</span>

                                          <p class="content">Fakta Pembunuhan Guru Honorer Terungkap! Pelaku Memotong Kepala Korban Secara Bergantian</p>
                                    </div>
                                    <span class="badge">Hot</span>
                                    <span class="cover"></span>
                              </a>
                        </div>



                        <ul class="list-type-1">
                              <li>

                                    <a href="#" class="lnk _link_home " title="China Tanggapi Laporan Media Pakistan Tentang " Perjodohan Ilegal"" data-title="digest_article" data-order="0" data-articleid="68248963" data-pbt="1555210949000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img" style="background-image:url(<?php echo base_url(); ?>assets/img/news/w580.jpeg)">

                                          </figure>
                                          <div class="text">
                                                <p class="content">China Tanggapi Laporan Media Pakistan Tentang "Perjodohan Ilegal"</p>
                                                <span class="media _media">VOA Indonesia</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Gunung Merapi Luncurkan Awan Panas Guguran Minggu Pagi Ini" data-title="digest_article" data-order="1" data-articleid="68248222" data-pbt="1555212180000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img" style="background-image:url(<?php echo base_url(); ?>assets/img/news/w580-2.jpeg)">

                                          </figure>
                                          <div class="text">
                                                <p class="content">Gunung Merapi Luncurkan Awan Panas Guguran Minggu Pagi Ini</p>
                                                <span class="media _media">Kompas.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Geger Akun Said Didu Di-hack, Fitnah Ustaz Abdul Somad" data-title="digest_article" data-order="2" data-articleid="68248166" data-pbt="1555212180000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img" style="background-image:url(<?php echo base_url(); ?>assets/img/news/w580-3.jpeg)">

                                          </figure>
                                          <div class="text">
                                                <p class="content">Geger Akun Said Didu Di-hack, Fitnah Ustaz Abdul Somad</p>
                                                <span class="media _media">VIVA.CO.ID</span>

                                          </div>

                                    </a>
                              </li>

                        </ul>
                  </div>


                  <div class="operation-module ">
                        <div class="bx-title">

                              <h3 class="section-title">LATEST NEWS</h3>
                        </div>
                        <ul class="list-type-1">
                              <li>

                                    <a href="#" class="lnk _link_home " title="Peserta Pemilu Bisa Ambil Alat Peraga Kampanye yang Ditertibkan Satpol PP" data-title="system6301" data-order="0" data-articleid="68257665" data-pbt="1555224060000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img fig-lazy" data-background="<?php echo base_url(); ?>assets/img/news/w580-4.jpeg">

                                          </figure>
                                          <div class="text">
                                                <p class="content">Peserta Pemilu Bisa Ambil Alat Peraga Kampanye yang Ditertibkan Satpol PP</p>
                                                <span class="media _media">Kompas.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Gubernur Jawa Tengah gelar lomba daur ulang alat peraga kampanye" data-title="system6301" data-order="1" data-articleid="68260881" data-pbt="1555227362000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img fig-lazy" data-background="<?php echo base_url(); ?>assets/img/news/w580-5.jpeg">

                                          </figure>
                                          <div class="text">
                                                <p class="content">Gubernur Jawa Tengah gelar lomba daur ulang alat peraga kampanye</p>
                                                <span class="media _media">antaranews.com</span>

                                          </div>

                                    </a>
                              </li>
                              <li>

                                    <a href="#" class="lnk _link_home " title="Bawaslu DKI: Jakut Paling Rawan Terjadi Kecurangan Pemilu" data-title="system6301" data-order="2" data-articleid="68253355" data-pbt="1555224540000" data-module="322" data-categoryname="News">
                                          <figure class="fig-img fig-lazy" data-background="<?php echo base_url(); ?>assets/img/news/w580-6.jpeg">

                                          </figure>
                                          <div class="text">
                                                <p class="content">Bawaslu DKI: Jakut Paling Rawan Terjadi Kecurangan Pemilu</p>
                                                <span class="media _media">Okezone.com</span>

                                          </div>

                                    </a>
                              </li>

                        </ul>
                  </div>
            </div>

            <aside class="right-area" id="right_area">

                  <div class="aside-section popular _side_popular">
                        <h3 class="section-title">Populer</h3>
                        <div id="nav" class="nav">
                              <div class="scroll_wrap swiper-container">
                                    <ul class="nav_u _scroller">



                                          <li class="_slide _link" data-tabid="100270" data-tabindex="0" data-tabname="Semua"><a href="#" class="nav_a" title="Semua">Semua</a></li>


                                          <li class="_slide _link nav_lon" data-tabid="100271" data-tabindex="4" data-tabname="News"><a href="#" class="nav_a" title="News">News</a></li>


                                          <li class="_slide _link" data-tabid="100293" data-tabindex="5" data-tabname="Sports"><a href="#" class="nav_a" title="Sports">Sports</a></li>

                                    </ul>
                              </div>
                              <div class="bx-btn">
                                    <button type="button" class="sp btn-prev _slide_popular_prev _link"><span class="blind">Prev</span></button>
                                    <button type="button" class="sp btn-next _slide_popular_next _link"><span class="blind">Next</span></button>
                              </div>
                              <span class="cover"></span>
                        </div>
                        <ol class="list-type-rk _side_popular_100270" style="display:none">
                              <li>

                                    <a href="#" class="subtit _link _popular " title="3 Akun Twitter dan Instagram Dilaporkan ke Polisi oleh Tersangka Pengeroyok Siswi SMP" data-articleid="68223605" data-order="0" data-pbt="1555191420000">
                                          3 Akun Twitter dan Instagram Dilaporkan ke Polisi oleh Tersangka Pengeroyok Siswi SMP
                                    </a>
                                    <span class="media _media">Kompas.com</span>

                              </li>
                              <li>

                                    <a href="#" class="subtit _link _popular " title="Klasemen Liga Inggris: MU Salip Arsenal" data-articleid="68250667" data-order="1" data-pbt="1555215060000">
                                          Klasemen Liga Inggris: MU Salip Arsenal
                                    </a>
                                    <span class="media _media">Liputan6.com</span>

                              </li>
                        </ol>
                        
                        
                        </ol>
                        <ol class="list-type-rk _side_popular_100271" style="display:block">
                              <li>

                                    <a href="#" class="subtit _link _popular " title="3 Akun Twitter dan Instagram Dilaporkan ke Polisi oleh Tersangka Pengeroyok Siswi SMP" data-articleid="68223605" data-order="0" data-pbt="1555191420000">
                                          3 Akun Twitter dan Instagram Dilaporkan ke Polisi oleh Tersangka Pengeroyok Siswi SMP
                                    </a>
                                    <span class="media _media">Kompas.com</span>

                              </li>
                        </ol>
                        <ol class="list-type-rk _side_popular_100293" style="display:none">
                              <li>

                                    <a href="https://today.line.me/id/pc/article/Klasemen+Liga+Inggris+MU+Salip+Arsenal-nEvvLM" class="subtit _link _popular " title="Klasemen Liga Inggris: MU Salip Arsenal" data-articleid="68250667" data-order="0" data-pbt="1555215060000">
                                          Klasemen Liga Inggris: MU Salip Arsenal
                                    </a>
                                    <span class="media _media">Liputan6.com</span>

                              </li>
                        </ol>
                        
                        <a href="#" class="btn-more _side_popular_more _link" data-currentid="100271" data-index=2 data-categoryname="News" title="Lainnya">Lainnya</a>
                  </div>

            

            </aside>
      </div>
</div>
