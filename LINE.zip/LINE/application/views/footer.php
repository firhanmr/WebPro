<!-- footer -->
<footer id="footer" >
    <div class="inner">

        <div class="bx-left">
    
            <p class="copyright">&copy; LINE Corporation</p>
        </div>
        <div class="bx-right">
            <a href="https://www.facebook.com/linetoday/" class="fb-banner _link" target="_blank" data-name="facebook" title="Ikuti kami">
                Ikuti kami
                <span class="sp">Ikuti kami</span>
            </a>
            
        </div>
    </div>
</footer>
<!-- //footer -->
	</div>

<?php include "js.php"?>
</body>
</html>