<!DOCTYPE html>
<html>

<head>


  <style>
    .right-area .section-banners.rightArea-bannerTop {
      margin-bottom: 24px;
    }

    .right-area .section-banners.rightArea-bannerBottom {
      margin-top: 24px;
    }

    .right-area .section-banners.rightArea-bannerTopVideo {
      margin-bottom: 20px;
      margin-right: -25px;
      width: 344px;
    }

    .right-area .section-banners.rightArea-bannerBottomVideo {
      margin-top: 24px;
      margin-right: -25px;
    }

    .leftArea-bannerOnMain {
      margin: 70px 0 66px 0;
    }

    .left-area .leftArea-bannerOnComments {
      margin: 70px 0 8px 0;
    }

    .left-area .leftArea-bannerOnVideo {
      margin-top: 24px;
      margin-bottom: 100px;
    }

    /* this is to compensate the addition of margin-bottom from the ad */

    .video-end .left-area {
      margin: 0 -1px 0 0;
    }

    .video-end aside.right-area {
      padding-bottom: 84px;
    }
  </style>
  <link href="<?= base_url(); ?>assets/bootstrap/css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/dist/style.css" rel="stylesheet">


</head>

<body class="ID">
  <div id="wrap">
    <!-- browser-recommended -->

    <!-- header -->
    <header id="header">
      <div class="inner">
        <h1><a href="<?php echo base_url(); ?>" class="sp logo _link _logo" title="LINE TODAY"><span class="blind" style="color:fff">LINE Today</span></a></h1>
        <nav>
          <ul class="gnb">

            <li data-order="0" data-name="TOP" class="on _link _category">
              <a href="<?php echo base_url(); ?>line/index" title="TOP">
                TOP
              </a>
            </li>

            <li data-order="3" data-name="Showbiz" class=" _link _category">
              <a href="<?php echo base_url(); ?>line/sport" title="Sport">
                Sport
              </a>
            </li>


            <li data-order="6" data-name="News" class=" _link _category">
              <a href="<?php echo base_url(); ?>line/news" title="News">
                News
              </a>
            </li>
              
            <li data-order="4" data-name="Channel" class=" _link _category">
              <a href="<?php echo base_url('index.php/web/mahasiswa'); ?>" title="story">
                Story
              </a>
            </li>

            <li data-order="4" data-name="Channel" class=" _link _category">
              <a href="<?php echo base_url(); ?>line/registrasi" title="Registrasi">
                Registrasi
              </a>
            </li>

          </ul>
        </nav>

        <div class="bx-login" id="">
          <a href="<?php echo base_url(); ?>line/login" title="Registrasi"><button type="button" class="login _login _link">Login</button></a>


        </div>
      </div>
    </header>
    <!-- //header -->