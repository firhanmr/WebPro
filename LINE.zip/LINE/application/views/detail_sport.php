<!-- container -->
<div class="article-end">
  <div class="inner">
    <div class="left-area" id="left_area">
      <div id="article" class="article-info">
        <!-- header -->
        <section>
          <h2 class="news-title" itemprop="headline">Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China</h2>
          <dl class="news-info">
            <dt class="blind">CP name</dt>
            <dd class="publisher" itemprop="publisher">
              CNN Indonesia
            </dd>
            
          </dl>
        </section>
        <!-- like and comment button -->
       
          
         

        <!-- container -->
        <div id="container">
          <!-- TODO : content? markup? CMS? ??? ?? ??? ???? ???. -->
          <article class="article-content news-content" itemprop="articleBody">
            <figure class="fig-cont include-image"><img data-hashid="0hCvihIdwtHFlUETaPqihjDm5HHzZnfQ9aMCdNRwR_Qm0rcltYanAHbHhDQmgrclsHOiNQOnQRB2hxdQ8POHMH" src="<?php echo base_url(); ?>assets/img/w644.jpg" alt="">
              <figcaption></figcaption>
            </figure>
            <p><b>Mohammad Ahsan</b>/<b>Hendra Setiawan</b> tidak menyangka dapat meraih kemenangan dengan jarak skor yang cukup jauh atas ganda China Li Junhui/Liu Yuchen dalam semifinal <b>Singapura Terbuka 2019</b>.</p>
            <p>Pasangan peringkat empat dunia itu hanya butuh waktu kurang dari setengah jam untuk menyudahi perlawanan pasangan nomor dua dunia dengan skor 21-11 dan 21-14.</p>
            <p>&quot;Pastinya kami bersyukur alhamdulillah. Enggak nyangka poinnya bisa jauh. Tapi kami enggak boleh lengah juga. Mereka punya kualitas yang bagus, kalau mereka berkembang bisa jadi bumerang buat kami.&quot;</p>
            <figure class="fig-cont include-image"><img data-hashid="0huqmiDepNKl5QEACIrihVCWpGKTFjfDldNCZ7QAB-dGovc21fbnEya3xDd2d4cG0APiJmPXIXMW91dDkIPHIy" src="<?php echo base_url(); ?>assets/img/w644a.jpg" alt="">
              <figcaption>Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China</figcaption>
            </figure>
            <p>Mohammad Ahsan/Hendra Setiawan berhadapan dengan ganda China dalam semifinal Singapura Terbuka 2019. (Reuters/Andrew Boyers) &quot;Mudah sih enggak, mungkin terlihat menang mudah, tapi enggak. Harus tetap fokus, walaupun poinnya beda jauh, kesempatan mereka buat mengejar itu ada. Jadi kami nggak mau lengah. Siap menekan dan siap fokus,&quot; jelas Ahsan.</p>
            <p>Kemenangan di Singapura sekaligus membalas kekalahan Ahsan/Hendra di kejuaraan Malaysia Terbuka pada pekan lalu.</p>
            <figure class="fig-cont include-image"><img data-hashid="0hoarj_kAbME5PExqYsSlPGXVFMyF8fyNNKyVhUB99bnowcHdPcXIqe2MXOn9rJXcQISF8LWgWK39qdyMYI3Eq" src="<?php echo base_url(); ?>assets/img/w644b.jpg" alt="">
              <figcaption>Ahsan/Hendra Tak Sangka Menang Telak Atas Ganda China</figcaption>
            </figure>
            <p>&quot;Mereka lebih gampang tembus pertahanannya. Di Malaysia kemarin mereka lebih rapat mainnya,&quot; ucap Ahsan.</p>
            <p>&quot;Hari ini mereka mungkin kurang dapat juga <i>feelingnya</i>,&quot; imbuh Hendra.</p>
            <p>Pada babak final, Hendra/Ahsan akan bertemu Takeshi Kamura/Keigo Sonoda asal Jepang. Dari empat pertemuan, Ahsan/Hendra menang tiga kali. Pada pertemuan terakhir yang terjadi di All England 2019, Hendra/Ahsan menang 21-19 dan 21-16.</p>
            <p>&quot;Besok siap capek saja. Mereka lebih rapat mainnya tadi saya lihat. Jadi siap capek saja. Poin-poin akhir mereka lebih berani juga,&quot; ujar Hendra.</p>
            <p>Selain Ahsan/Hendra, Indonesia memiliki peluang meraih gelar juara dari sektor tunggal putra melalui Anthony Sinisuka Ginting yang akan menghadapi Kento Momota.</p>
            <!-- original article -->
            

          </article>



          <!-- comment -->


          <!-- /comment -->
        </div>
        <!-- /container -->
      </div>
      <!-- /wrap -->
    </div>

    


 
  </div>
</div>
<!-- //container -->