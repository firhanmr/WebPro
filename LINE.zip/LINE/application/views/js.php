<script src="<?= base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">
LINE = {};
LINE.GLN = {};
LINE.GLN.LOCATION = "ID".toUpperCase();


var COUNTRY = "ID".toUpperCase();
var isV3 = true;

window.GLN_EVENTS=[];

</script>
<script type="text/javascript">
window.layoutType = 301;
</script>
<script type="text/javascript">
window.currentCategoryName = 'TOP'
window.currentCategoryId = '100270'
  window.categoryOrder = 0
</script>


<script type="text/javascript" src="<?= base_url();?>assets/bootstrap/js/vendor.js"></script>
<script type="text/javascript" src="<?= base_url();?>assets/bootstrap/js/js-common.js"></script>
<script type="text/javascript" src="<?= base_url();?>assets/bootstrap/js/pc-main.js"></script>